from flask import Flask, jsonify, request
from Blockchain import Blockchain
from Block import Block
from timeit import default_timer as timer
import requests # Needed for broadcasting
from argparse import ArgumentParser

# Instantiate the Node
app = Flask(__name__)

# Instantiate the Blockchain
blockchain = Blockchain()

# --- PEER MANAGEMENT ---
# Set to store all known network addresses (peers)
PEERS = set() 
# We remove the hardcoded PEERS.add() line here
# -----------------------


# Function to handle initial peer connection and synchronization
def connect_to_peer(boot_peer_address, my_address):
    """
    Connects to the bootstrap peer, registers self, and gets the full peer list.
    Then registers self with all newly discovered peers.
    """
    print(f"Attempting to connect to bootstrap peer: {boot_peer_address}")
    try:
        # 1. Register self with the bootstrap peer
        response = requests.post(f'{boot_peer_address}/register_node', json={'nodes': [my_address]}, timeout=5)
        
        if response.status_code == 201:
            # 2. Get the full list of known peers from the response
            new_peers = response.json().get('total_nodes', [])
            
            # Add all known peers to our PEERS set
            for peer in new_peers:
                # IMPORTANT: Only add peers that are NOT the current peer
                if peer != my_address:
                    PEERS.add(peer)
            
            # Also register the boot peer itself if it's not already in the set
            PEERS.add(boot_peer_address)

            print(f"Successfully registered with {boot_peer_address}. Total known peers: {len(PEERS)}")
            
            # 3. Broadcast self to all newly discovered peers (excluding self and boot_peer)
            for peer in new_peers:
                if peer != my_address and peer != boot_peer_address:
                    try:
                        # Register our address with the new peer
                        requests.post(f'{peer}/register_node', json={'nodes': [my_address]}, timeout=2)
                        print(f"Registered self with new peer: {peer}")
                    except requests.exceptions.ConnectionError:
                        print(f"Warning: Could not connect to new peer {peer} for registration.")
            
            # NOTE: A real implementation would now check for the longest chain (consensus/replace_chain)

    except requests.exceptions.ConnectionError:
        print(f"Error: Could not connect to bootstrap peer {boot_peer_address}. Starting peer without network connection.")

# Function to run the Proof of Work and mine a new block
def mine_pending_transactions():
    """Finds the proof for the next block and mines it."""
    start = timer()
    
    # 1. Create a Block object for mining (using pending transactions)
    mining_block = Block(
        index=len(blockchain.chain) + 1, 
        transactions=blockchain.pending_transactions, 
        prev_hash=blockchain.hash(blockchain.last_block)
    )
    
    # 2. Run the POW algorithm
    mined_hash = blockchain.p_o_w_2(mining_block) 
    
    # 3. Create the new block in the blockchain list
    block = blockchain.create_new_block(proof=mined_hash, prev_hash=mining_block.prev_hash)
    
    end = timer()
    print("Mined Block #{} in {:.4f} seconds".format(block['index'], end - start))
    
    # CRUCIAL FIX: Save the updated chain to disk
    blockchain.save_chain()
    
    # CRUCIAL FIX: Broadcast the new block to all other peers
    broadcast_new_block(block)

    return block

def broadcast_new_block(block):
    """Broadcasts the newly mined block to all known peers."""
    for node in PEERS:
        # Skip broadcasting to self if the node is running the client/peer
        if node != f'http://127.0.0.1:{app.config["SERVER_PORT"]}': 
            try:
                # Send the block data to the peer's /block/receive endpoint
                requests.post(f'{node}/block/receive', json=block, timeout=5)
                print(f"Broadcasted block {block['index']} to {node}")
            except requests.exceptions.ConnectionError:
                print(f"Warning: Could not connect to peer {node} for broadcast.")

# --- NEW ROUTE: Manual Node Registration (Now used for dynamic registration) ---
@app.route('/register_node', methods=['POST'])
def register_node():
    values = request.get_json()
    nodes = values.get('nodes')
    if nodes is None:
        return "Error: Please supply a valid list of nodes", 400

    # Ensure the current peer is in the list before returning it
    current_peer_address = f'http://127.0.0.1:{app.config["SERVER_PORT"]}'
    PEERS.add(current_peer_address)

    for node in nodes:
        PEERS.add(node)

    response = {
        'message': 'New nodes have been added',
        # CRUCIAL: Return the full list of ALL known peers, including self, to the registering node
        'total_nodes': list(PEERS), 
    }
    return jsonify(response), 201

# --- NEW ROUTE: Receive Block from another Peer ---
@app.route('/block/receive', methods=['POST'])
def receive_block():
    received_block = request.get_json()
    
    # Simple validation (we assume the received block is valid for this simple demonstration)
    if received_block:
        # Check if the block is already in our chain (to prevent duplicates)
        if received_block['index'] <= len(blockchain.chain):
            return "Block already in chain", 200

        # Note: In a real project, we would validate the POW and the previous hash here.
        
        # Add the received block to our chain and save it.
        blockchain.chain.append(received_block)
        blockchain.save_chain() # Save the chain immediately after receiving a new block
        print(f"Received and added Block #{received_block['index']} from network.")
        return "Block added to the chain", 201
    
    return "Invalid Block Data", 400
# ----------------------------------------------


@app.route('/new_transaction', methods=['POST'])
def new_transaction():
    values = request.get_json()

    required = ['user', 'v_file', 'file_data', 'file_size']
    if not all(k in values for k in required):
        return 'Missing values', 400

    # Create the new transaction
    index = blockchain.new_transaction(values['user'], values['v_file'], values['file_data'], values['file_size'])
    
    # CRUCIAL FIX: Immediately mine the transaction and save the chain
    mine_pending_transactions()
    
    response = {'message': f'Transaction will be added to Block {index}'}
    return jsonify(response), 201

@app.route('/chain', methods=['GET'])
def full_chain():
    # Load chain from disk before responding to ensure data is fresh
    blockchain.load_chain() 
    
    response = {
        'chain': blockchain.chain,
        'length': len(blockchain.chain),
    }
    print("Chain Len: {}".format(response['length']))
    return jsonify(response), 200

@app.route('/mine', methods=['GET'])
def mine():
    block = mine_pending_transactions()
    response = {
        'message': "New Block Mined",
        'index': block['index'],
        'transactions': block['transactions'],
        'proof': block['proof'],
        'prev_hash': block['prev_hash'],
    }
    return jsonify(response), 200

if __name__ == '__main__':
    parser = ArgumentParser()
    parser.add_argument('-p', '--port', default=8800, type=int, help='port to listen on')
    # NEW ARGUMENT: Allows specifying a known peer for initial connection
    parser.add_argument('--boot-peer', default=None, type=str, help='address of a known peer to connect to (e.g., http://127.0.0.1:8800)')
    args = parser.parse_args()
    port = args.port
    
    app.config['SERVER_PORT'] = port # Store port for broadcast logic
    
    current_peer_address = f'http://127.0.0.1:{port}'

    # NEW LOGIC: Connect to a bootstrap peer on startup
    if args.boot_peer:
        connect_to_peer(args.boot_peer, current_peer_address)

    # Add self to the PEERS list
    PEERS.add(current_peer_address)

    app.run(host='127.0.0.1', port=port, debug=True)