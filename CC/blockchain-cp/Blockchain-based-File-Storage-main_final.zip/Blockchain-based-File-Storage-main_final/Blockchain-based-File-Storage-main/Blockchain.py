import hashlib
import json
import time
import random

# Assuming the Block class is imported or defined correctly
from Block import Block 

class Blockchain:
    # Set a global difficulty that both POW methods will respect (default is 3)
    difficulty = 3 

    def __init__(self):
        self.chain = []
        self.pending_transactions = []
        self.load_chain()
    
    def load_chain(self):
        try:
            with open("blockchain.txt", "r") as f:
                data = json.load(f)
                self.chain = data["chain"]
                self.pending_transactions = data["pending_transactions"]
        except (FileNotFoundError, json.JSONDecodeError):
            self.create_genesis_block()

    def save_chain(self):
        """Saves the current chain and pending transactions to blockchain.txt."""
        with open("blockchain.txt", "w") as f:
            data = {
                "chain": self.chain,
                "pending_transactions": self.pending_transactions
            }
            json.dump(data, f, indent=4) 

    def create_genesis_block(self):
        # Create the very first block in the chain
        # Note: We'll use the iterative POW method for the main app
        self.create_new_block(proof=100, prev_hash=0)

    def create_new_block(self, proof, prev_hash=None):
        block = {
            'index': len(self.chain) + 1,
            'timestamp': time.time(),
            'transactions': self.pending_transactions,
            'proof': proof,
            'prev_hash': prev_hash or self.hash(self.chain[-1]) if self.chain else 0,
        }
        
        self.pending_transactions = []
        self.chain.append(block)
        return block

    # --- PROOF OF WORK ALGORITHM 1 (RANDOM NONCE) ---
    def p_o_w(self, block):
        """Mines block using random nonce."""
        block.nonce = 0
        while True:
            block.nonce = random.randint(0, 99999999) # Random Nonce
            hash_val = block.generate_hash()
            if hash_val.startswith('0' * self.difficulty):
                # The peer server needs the hash value to display the file on the dashboard
                return hash_val # Return the mined hash
    
    # --- PROOF OF WORK ALGORITHM 2 (ITERATIVE NONCE) ---
    def p_o_w_2(self, block):
        """Mines block using iterative nonce."""
        block.nonce = 0
        while True:
            block.nonce += 1 # Iterative Nonce
            hash_val = block.generate_hash()
            if hash_val.startswith('0' * self.difficulty):
                # The peer server needs the hash value to display the file on the dashboard
                return hash_val # Return the mined hash
                
    def new_transaction(self, user, v_file, file_data, file_size):
        self.pending_transactions.append({
            'user': user,
            'v_file': v_file,
            'file_data': file_data,
            'file_size': file_size,
            'timestamp': time.time()
        })
        return self.last_block['index'] + 1

    @staticmethod
    def hash(block):
        # Hashes a block
        block_string = json.dumps(block, sort_keys=True).encode()
        return hashlib.sha256(block_string).hexdigest()

    @property
    def last_block(self):
        return self.chain[-1]